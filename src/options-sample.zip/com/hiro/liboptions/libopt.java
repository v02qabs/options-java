packages com.hiro.liboptions;

class libopt{
	public static void main(String[] args){
		System.out.println("Hello libopt.java");
	}
	public libopt(){
		}
	public int col;

	public void setOptCoulm(int coulm){
		this.col = coulm;
	}
	public  


}

